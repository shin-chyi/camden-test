import 'core-js/stable';
import 'regenerator-runtime/runtime';
import objectFitImages from 'object-fit-images';

document.addEventListener('DOMContentLoaded', () => {
    objectFitImages();
});
